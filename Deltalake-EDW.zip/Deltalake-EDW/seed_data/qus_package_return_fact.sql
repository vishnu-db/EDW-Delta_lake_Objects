-- Databricks notebook source
sql command